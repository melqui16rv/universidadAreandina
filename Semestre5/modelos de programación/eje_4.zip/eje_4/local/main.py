# main.py
from app import server

if __name__ == '__main__':
    server.iniciar_servidor()