from app.cliente import iniciar_cliente

if __name__ == "__main__":
    iniciar_cliente()
